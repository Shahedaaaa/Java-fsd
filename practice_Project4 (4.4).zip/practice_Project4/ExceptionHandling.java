package practice_Project4;

import java.util.Scanner;

public class ExceptionHandling {
	Scanner sc=new Scanner(System.in);
	void meth1()
	{
		System.out.println(10);
		try
		{
			System.out.println("try block executed");
			System.out.println("please enter the number");
			System.out.println("===>" +20/sc.nextInt());
		}
		catch(ArithmeticException e)
		{
			System.out.println("catch block executed");
			e.printStackTrace();
		}
		finally
		{
			System.out.println("finally block executed");
		}
		System.out.println(30);
	
	}
	public static void main(String[] args) {
		ExceptionHandling e=new ExceptionHandling();
		e.meth1();
	}

}
