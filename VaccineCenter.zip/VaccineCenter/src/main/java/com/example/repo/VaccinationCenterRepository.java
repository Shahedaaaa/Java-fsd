package com.example.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.entities.VaccinationCenter;

public interface VaccinationCenterRepository extends CrudRepository<VaccinationCenter, Integer> {

	List<VaccinationCenter> findByCenterName(String centerName);
	
	List<VaccinationCenter> findAll();
}
