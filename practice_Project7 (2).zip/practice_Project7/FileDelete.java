package practice_Project7;

import java.io.File;

public class FileDelete {
	public static void main(String[] args) {
		File myFile=new File("input3");
		if(myFile.delete())
		{
			System.out.println("File deleted. "+myFile.getName());
		}
		else
		{
			System.out.println("Failed to delete.");
		}
	}

}
