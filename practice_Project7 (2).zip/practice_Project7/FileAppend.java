package practice_Project7;

import java.io.FileWriter;

public class FileAppend {
		public static void main(String[] args) {
			String data="This data is appended";
			try
			{
				FileWriter output=new FileWriter("input3",true);
				output.write(data);
				System.out.println("Data appended successfully");
				output.close();
			}
			catch (Exception e) {
				// TODO: handle exception
				System.out.println("file append error...");
			}
			
		}

	}




