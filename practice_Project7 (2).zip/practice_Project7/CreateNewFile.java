package practice_Project7;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;

public class CreateNewFile {
	 public static void main(String[] args)  {

        File myFile=new File("input3");
    
	 try {
		if(myFile.createNewFile())
		 {
			 System.out.println("file created");
			 
		 }
		 else {
			 System.out.println("file creation error");
		 }
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

