package practice_Project7;

import java.io.FileWriter;
import java.io.IOException;

public class FileWrite {

		public static void main(String[] args) {
			String data="Hello user";
			try {
				FileWriter output=new FileWriter("input3");
				output.write(data);
				System.out.println("data is written successfully");
				output.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}



