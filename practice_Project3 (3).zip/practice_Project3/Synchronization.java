package practice_Project3;

public class Synchronization extends Thread {
	public void run()
	{
		criticalResource();
	}
	
	synchronized void criticalResource()
	{
		String name=Thread.currentThread().getName();
		System.out.println(name+" has entered criticalResource()");
		for(int i=1;i<=5;i++)
		{
			System.out.println(name+ "i value: "  +i);
		}
		System.out.println("completed execution ");
	}
	public static void main(String[] args) {
		Synchronization s=new Synchronization();
		Thread t1=new Thread(s);
		Thread t2=new Thread(s);
		t1.setName("First Thread");
		t2.setName("Second Thread");
		t2.setPriority(MAX_PRIORITY);
		t1.setPriority(MIN_PRIORITY);
		t1.start();
		t2.start();

	}

}
