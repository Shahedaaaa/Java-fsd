package practice_Project2;

public class acesssSpecifier1 
{
		public static void main(String[] args) {
			//default
			System.out.println("Dafault Access Specifier");
			defAccessModifier obj = new defAccessModifier(); 		  
	       obj.display(); 

		}

}
