package com.ecommerce;

import org.springframework.context.ApplicationListener;

public class CustomerEventListener implements ApplicationListener<CustomerEvent>{
	   public void onApplicationEvent(CustomerEvent event) {
		      System.out.println(event.toString());
		   }

}
