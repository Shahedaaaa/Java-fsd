package practice_Project1;

import java.util.Arrays;
import java.util.Scanner;

public class linearSearch {
	public static void main(String[] args) {
		int a[]= {2,4,1,6,3,5,9};
		Arrays.sort(a);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the key value to search");
		System.out.println("The sorted array is ");
		for(int i:a)
		{
			System.out.println(i);
		}
		System.out.println("enter the value to search");
		int key=sc.nextInt();
		int i=0;
		int flag=0;
		for(i=0;i<a.length;i++)
		{
			if(a[i]==key)
			{
				flag=1;
				break;
			}
			else
			{
				flag=0;
			}
		}
		if(flag==1)
		{
			System.out.println("element is found at" +i);
		}
		else
		{
			System.out.println("element is not found");
		}
		

	}


}
