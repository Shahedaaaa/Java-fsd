package com.hibernate.proj;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity  
@Table(name= "annotation")   
public class Annotation {
    @Id @GeneratedValue   
    @Column(name = "pid")
    private long pid;
    
    @Column(name = "pname")
    private String pname;
    
    @Column(name = "pcost")
    private BigDecimal pcost;
    
   
        
    public long getID() {return this.pid; }
    public String getName() { return this.pname;}
    public BigDecimal getPrice() { return this.pcost;}
    
    public void setID(long id) { this.pid = id;}
    public void setName(String name) { this.pname = name;}
    public void setPrice(BigDecimal price) { this.pcost = price;}


}
