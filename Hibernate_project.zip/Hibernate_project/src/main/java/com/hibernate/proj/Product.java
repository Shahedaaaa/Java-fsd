package com.hibernate.proj;

import java.math.BigDecimal;
import java.util.Date;

public class Product {
	private long pid;
    private String pname;
    private BigDecimal pcost;
    
    public Product() {
            
    }
    public Product(long id, String name, BigDecimal price) {
            this.pid = id;
            this.pname = name;
            this.pcost = price;
    }
    
    public long getID() {return this.pid; }
    public String getName() { return this.pname;}
    public BigDecimal getPrice() { return this.pcost;}
    
    public void setID(long id) { this.pid = id;}
    public void setName(String name) { this.pname = name;}
    public void setPrice(BigDecimal price) { this.pcost = price;}

}
