package com.camerarentalapp.main;

import java.util.Scanner;

import com.camerarentalapp.CameraDetails;

public class CameraMain {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        CameraDetails cd=new CameraDetails();
        cd.CheckDetails(scanner);
		
		
	}
	
	

}
