package com.camerarentalapp;

public class Camera {
	private   int id;
	private String brand;
	private String model;
	private double price_perday;
    private boolean available;
	public Camera(int id, String brand, String model, double price, boolean available) {
		super();
		this.id = id;
		this.brand = brand;
		this.model = model;
		this.price_perday = price;
		this.available = available;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public double getPrice_perday() {
		return price_perday;
	}
	public void setPrice_perday(float price_perday) {
		this.price_perday = price_perday;
	}
	public boolean isAvailable() {
		return available;
	}
	public void setAvailable(boolean available) {
		this.available = available;
	}
	

}
