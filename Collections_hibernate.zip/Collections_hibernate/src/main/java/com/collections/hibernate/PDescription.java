package com.collections.hibernate;

public enum PDescription {
	;

	public String getDescrip() {
		// TODO Auto-generated method stub
		return null;
	}

}
