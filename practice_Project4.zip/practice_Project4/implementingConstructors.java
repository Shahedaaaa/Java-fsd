package practice_Project4;

public class implementingConstructors {

	implementingConstructors()
	{
		System.out.println("Non-parameterized constructor called");
		new implementingConstructors("Java is awesome").meth2();;
		
	}
	implementingConstructors(String s)
	{
		System.out.println(s);
		
	}
	implementingConstructors(int a,int b)
	{
		System.out.println(a+b);
	}
	void meth1()
	{
		System.out.println("meth1() called");
		
	}
	void meth2()
	{
		System.out.println("meth2() called");
		new implementingConstructors(99,1);
	}
	public static void main(String[] args) 
	{
		implementingConstructors aobj=new implementingConstructors();
		aobj.meth1();
		
	}

}
