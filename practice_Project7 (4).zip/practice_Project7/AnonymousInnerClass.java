package practice_Project7;

public abstract class AnonymousInnerClass {
	//anonymous inner class
	   public abstract void display();

}
